package ar.org.centro8.curso.java.gui;

import ar.org.centro8.curso.java.connectors.Connector;
import ar.org.centro8.curso.java.entities.Detalle;
import ar.org.centro8.curso.java.entities.Factura;
import ar.org.centro8.curso.java.enums.FormaDePago;
import ar.org.centro8.curso.java.enums.Tipo;
import ar.org.centro8.curso.java.enums.TipoProducto;
import ar.org.centro8.curso.java.repositories.interfaces.I_DetalleRepository;
import ar.org.centro8.curso.java.repositories.interfaces.I_FacturaRepository;
import ar.org.centro8.curso.java.repositories.jdbc.DetalleRepository;
import ar.org.centro8.curso.java.repositories.jdbc.FacturaRepository;
import ar.org.centro8.curso.java.utils.swing.Table;
import ar.org.centro8.curso.java.gui.FormDetalles;
import ar.org.centro8.curso.java.repositories.interfaces.I_LocalRepository;
import ar.org.centro8.curso.java.repositories.jdbc.LocalRepository;
import ar.org.centro8.curso.java.utils.swing.Validator;
import java.util.Comparator;
import javax.swing.JOptionPane;

public class FormFacturas extends javax.swing.JInternalFrame {

    private I_FacturaRepository fr = new FacturaRepository(Connector.getConnection());
    private I_DetalleRepository dr = new DetalleRepository(Connector.getConnection());
    private I_LocalRepository lr = new LocalRepository(Connector.getConnection());
    private int dia;
    private int mes;
    private int anho;
    public FormFacturas() {
        super(
                "Facturas",                     //title
                true,                           //resizable
                true,                           //closable
                true,                           //maximizable
                true                            //iconable
        );
        initComponents();
        cargar();
    }

    public void cargar(){
        // cargar cmbTipoProducto
        cmbTipo.removeAllItems();
        for (Tipo t : Tipo.values()) cmbTipo.addItem(t);
        // cargar cmbFormaDePago
        cmbFormaDePago.removeAllItems();
        for (FormaDePago fdp : FormaDePago.values()) cmbFormaDePago.addItem(fdp);
        // cargar tblProductos
        new Table().cargar(tblFacturas, fr.getAll());
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        lblTipo = new javax.swing.JLabel();
        lblNumero = new javax.swing.JLabel();
        lblIdLocal = new javax.swing.JLabel();
        lblFormaDePago = new javax.swing.JLabel();
        lblFecha = new javax.swing.JLabel();
        lblDia = new javax.swing.JLabel();
        txtDia = new javax.swing.JTextField();
        lblMes = new javax.swing.JLabel();
        lblAnho = new javax.swing.JLabel();
        txtAnho = new javax.swing.JTextField();
        txtNumero = new javax.swing.JTextField();
        txtIdLocal = new javax.swing.JTextField();
        cmbFormaDePago = new javax.swing.JComboBox<>();
        cmbTipo = new javax.swing.JComboBox<>();
        txtMes = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblFacturas = new javax.swing.JTable();
        btnMostrarDetalles = new javax.swing.JButton();
        btnFacturaNueva = new javax.swing.JButton();

        setTitle("Facturas");

        lblTipo.setText("Tipo:");

        lblNumero.setText("Número:");

        lblIdLocal.setText("IdLocal:");

        lblFormaDePago.setText("Forma de pago:");

        lblFecha.setText("Fecha:");

        lblDia.setText("Día:");

        lblMes.setText("Mes:");

        lblAnho.setText("Año:  20");

        txtAnho.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtAnhoKeyReleased(evt);
            }
        });

        txtNumero.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtNumeroKeyReleased(evt);
            }
        });

        txtIdLocal.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtIdLocalKeyReleased(evt);
            }
        });

        cmbFormaDePago.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmbFormaDePagoActionPerformed(evt);
            }
        });

        jScrollPane1.setViewportView(tblFacturas);

        btnMostrarDetalles.setText("Mostrar Detalles");
        btnMostrarDetalles.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnMostrarDetallesActionPerformed(evt);
            }
        });

        btnFacturaNueva.setText("Factura Nueva");
        btnFacturaNueva.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnFacturaNuevaActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(23, 23, 23)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 499, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(115, 115, 115)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(lblFormaDePago)
                                    .addComponent(lblFecha))
                                .addGap(34, 34, 34)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                        .addComponent(lblDia)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(txtDia, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(lblMes)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(txtMes, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(lblAnho)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(txtAnho, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addComponent(cmbFormaDePago, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 188, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(lblTipo)
                                    .addComponent(lblNumero)
                                    .addComponent(lblIdLocal))
                                .addGap(82, 82, 82)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addComponent(txtIdLocal, javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(txtNumero, javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(cmbTipo, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 54, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(176, 176, 176)
                        .addComponent(btnFacturaNueva, javax.swing.GroupLayout.PREFERRED_SIZE, 182, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(172, 172, 172)
                        .addComponent(btnMostrarDetalles, javax.swing.GroupLayout.PREFERRED_SIZE, 182, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(23, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(btnFacturaNueva)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblTipo)
                    .addComponent(cmbTipo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblNumero)
                    .addComponent(txtNumero, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblIdLocal)
                    .addComponent(txtIdLocal, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblFormaDePago)
                    .addComponent(cmbFormaDePago, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblFecha)
                    .addComponent(lblDia)
                    .addComponent(txtDia, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblMes)
                    .addComponent(lblAnho)
                    .addComponent(txtAnho, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtMes, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(btnMostrarDetalles)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 11, Short.MAX_VALUE)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 137, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnMostrarDetallesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnMostrarDetallesActionPerformed
        // Mostrar detalles de la factura seleccionada
        if(tblFacturas.getSelectedRow()==-1) JOptionPane.showMessageDialog(this, 
                "Seleccione una factura de la tabla.");
        int fila=tblFacturas.getSelectedRow();
        if(fila==-1) return;
        int id = (int) tblFacturas.getValueAt(fila, 0);
        Factura factura = fr.getById(id);
        FormDetalles fd = new FormDetalles(factura);
        this.getParent().add(fd);
        fd.setVisible(true);
    }//GEN-LAST:event_btnMostrarDetallesActionPerformed

    private void btnFacturaNuevaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnFacturaNuevaActionPerformed
        // Evento Factura Nueva
        FormVenta fv = new FormVenta();
        this.getParent().add(fv);
        fv.setVisible(true);
    }//GEN-LAST:event_btnFacturaNuevaActionPerformed

    private void txtNumeroKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtNumeroKeyReleased
        // Buscar por tipo y numero de factura
        if (txtNumero.getText().isEmpty() || txtNumero.getText()==""){
            txtIdLocal.setEditable(true);
            txtDia.setEditable(true);
            txtMes.setEditable(true);
            txtAnho.setEditable(true);
            cargar();
        } else{
            txtIdLocal.setEditable(false);
            txtDia.setEditable(false);
            txtMes.setEditable(false);
            txtAnho.setEditable(false);
            String tipo = cmbTipo.getItemAt(cmbTipo.getSelectedIndex()).name();
            int numero = Integer.parseInt(txtNumero.getText());
            new Table<Factura>().cargar(tblFacturas, fr.getByTipoAndNumero(
                Tipo.valueOf(tipo), numero));
        }
    }//GEN-LAST:event_txtNumeroKeyReleased

    private void txtIdLocalKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtIdLocalKeyReleased
        // Buscar por idLocal
        if (txtIdLocal.getText().isEmpty() || txtIdLocal.getText()==null){
            txtNumero.setEditable(true);
            txtDia.setEditable(true);
            txtMes.setEditable(true);
            txtAnho.setEditable(true);
            cargar();
        } else{
            txtNumero.setEditable(false);
            txtDia.setEditable(false);
            txtMes.setEditable(false);
            txtAnho.setEditable(false);
            int id = Integer.parseInt(txtIdLocal.getText());
            new Table<Factura>().cargar(tblFacturas, fr.getByLocal(lr.getById(id)));
        }
    }//GEN-LAST:event_txtIdLocalKeyReleased

    private void cmbFormaDePagoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbFormaDePagoActionPerformed
        // Buscar por forma de pago
        new Table<Factura>().cargar(tblFacturas, fr.getByFormaDePago(cmbFormaDePago.getItemAt(cmbFormaDePago.getSelectedIndex())));
    }//GEN-LAST:event_cmbFormaDePagoActionPerformed

    private void txtAnhoKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtAnhoKeyReleased
        // agregar anho
        
        if(txtDia.getText()=="" || txtDia.getText().isEmpty() || txtMes.getText()==""
                || txtMes.getText().isEmpty() || txtAnho.getText().isEmpty() || txtAnho.getText()==""){
         txtIdLocal.setEditable(true);
         txtNumero.setEditable(true);
         cargar();   
        } else {
            txtIdLocal.setEditable(false);
            txtNumero.setEditable(false);
            anho = Integer.parseInt(txtAnho.getText());
            mes = Integer.parseInt(txtMes.getText());
            dia = Integer.parseInt(txtDia.getText());
            String fechaIngresada = "20"+txtAnho.getText()+"-"+txtMes.getText()+"-"+txtDia.getText();
            System.out.println(fechaIngresada);
            new Table<Factura>().cargar(tblFacturas, fr.getLikeFecha(fechaIngresada));
        }
        
    }//GEN-LAST:event_txtAnhoKeyReleased
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnFacturaNueva;
    private javax.swing.JButton btnMostrarDetalles;
    private javax.swing.JComboBox<FormaDePago> cmbFormaDePago;
    private javax.swing.JComboBox<Tipo> cmbTipo;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lblAnho;
    private javax.swing.JLabel lblDia;
    private javax.swing.JLabel lblFecha;
    private javax.swing.JLabel lblFormaDePago;
    private javax.swing.JLabel lblIdLocal;
    private javax.swing.JLabel lblMes;
    private javax.swing.JLabel lblNumero;
    private javax.swing.JLabel lblTipo;
    private javax.swing.JTable tblFacturas;
    private javax.swing.JTextField txtAnho;
    private javax.swing.JTextField txtDia;
    private javax.swing.JTextField txtIdLocal;
    private javax.swing.JTextField txtMes;
    private javax.swing.JTextField txtNumero;
    // End of variables declaration//GEN-END:variables
}
