-- use cafeteria

-- Mostrar toda la tabla detalles incluyendo descripción de cada producto
select d.idFactura, d.idProducto, p.descripcion, d.precio
from detalles d join productos p on p.id=d.idProducto;

-- Mostrar todas las facturas del local 2 y su ubicación
select f.id, f.tipo, f.numero, f.idLocal, l.direccion, l.barrio, f.monto, f.masIVA, f.formaDePago
from facturas f join locales l on l.id=f.idLocal
where l.id=2;

-- Mostrar todas las bebidas de la tabla productos
select * from productos where tipo = 'BEBIDA';

-- Mostrar todos los granos de café de menos de $1000
select * from productos where tipo = 'GRANOS' and precio<1000;

-- Mostrar el total vendido sin IVA en todos los locales el día de hoy
select sum(monto) from facturas where fecha='2021-05-17';