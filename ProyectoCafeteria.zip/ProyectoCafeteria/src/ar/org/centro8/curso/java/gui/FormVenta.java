package ar.org.centro8.curso.java.gui;

import ar.org.centro8.curso.java.connectors.Connector;
import ar.org.centro8.curso.java.entities.Detalle;
import ar.org.centro8.curso.java.entities.Factura;
import ar.org.centro8.curso.java.entities.Local;
import ar.org.centro8.curso.java.entities.Producto;
import ar.org.centro8.curso.java.enums.FormaDePago;
import ar.org.centro8.curso.java.enums.Tipo;
import ar.org.centro8.curso.java.enums.TipoProducto;
import ar.org.centro8.curso.java.repositories.interfaces.I_DetalleRepository;
import ar.org.centro8.curso.java.repositories.interfaces.I_FacturaRepository;
import ar.org.centro8.curso.java.repositories.interfaces.I_LocalRepository;
import ar.org.centro8.curso.java.repositories.interfaces.I_ProductoRepository;
import ar.org.centro8.curso.java.repositories.jdbc.DetalleRepository;
import ar.org.centro8.curso.java.repositories.jdbc.FacturaRepository;
import ar.org.centro8.curso.java.repositories.jdbc.LocalRepository;
import ar.org.centro8.curso.java.repositories.jdbc.ProductoRepository;
import ar.org.centro8.curso.java.utils.swing.Table;
import java.util.Calendar;
import java.util.Comparator;
import java.util.Date;
import java.util.GregorianCalendar;
import javax.swing.JOptionPane;

public class FormVenta extends javax.swing.JInternalFrame {
    private I_ProductoRepository pr = new ProductoRepository(Connector.getConnection()); 
    private I_FacturaRepository fr = new FacturaRepository(Connector.getConnection());
    private I_DetalleRepository dr = new DetalleRepository(Connector.getConnection());
    private I_LocalRepository lr = new LocalRepository(Connector.getConnection());
    private int numero;
    private double monto=0;
    private Factura factura = new Factura();
    private Producto producto = new Producto();
    public FormVenta() {
        super(
                "Agregar Detalles",             //title
                true,                           //resizable
                false,                          //closable
                true,                           //maximizable
                true                            //iconable
        );
        initComponents();
        cargar();
    }

    private void cargar(){
        // Cargar cmbTipo
        cmbTipo.removeAllItems();
        for(Tipo t:Tipo.values()) cmbTipo.addItem(t);
        // Cargar cmbLocal
        cmbLocal.removeAllItems();
        lr.getAll().forEach(cmbLocal::addItem);
        // Cargar cmbFormaDePago
        cmbFormaDePago.removeAllItems();
        for(FormaDePago fdp:FormaDePago.values()) cmbFormaDePago.addItem(fdp);
        // Cargar Tabla de productos
        new Table().cargar(tblProductos, pr.getAll());
        // Cargar Monto
        txtMonto.setText("0");
        // Cargar Fecha
        Calendar formFecha = new GregorianCalendar();
        int anho = formFecha.get(Calendar.YEAR);
        int mes = formFecha.get(Calendar.MONTH);
        int dia = formFecha.get(Calendar.DAY_OF_MONTH);
        String fechaFactura = anho+"/"+mes+"/"+dia;
        txtFecha.setText(dia+"/"+mes+"/"+anho);
        // Cargar Número de factura
        numero=0;
        // Crear Factura
        factura.setTipo(Tipo.valueOf(cmbTipo.getItemAt(cmbTipo.getSelectedIndex())
                        .name().toUpperCase()));
        factura.setNumero(Integer.parseInt(txtNumero.getText()));
        factura.setIdLocal(cmbLocal.getItemAt(cmbLocal.getSelectedIndex()).getId());
        factura.setMonto(Double.parseDouble(txtMonto.getText()));
        factura.setMasIVA(Double.parseDouble(txtMonto.getText())*1.21);
        factura.setFormaDePago(FormaDePago.valueOf(cmbFormaDePago.getItemAt
                               (cmbFormaDePago.getSelectedIndex()).name().toUpperCase()));
        factura.setFecha(fechaFactura);
        fr.save(factura);
    }
    
    public void cargarTblCompras(){
        // Cargar TxpCompras
        new Table<Detalle>().cargar(tblCompras, dr.getByFactura(factura));
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        lblNumero = new javax.swing.JLabel();
        lblMonto = new javax.swing.JLabel();
        txtNumero = new javax.swing.JTextField();
        txtMonto = new javax.swing.JTextField();
        lblTipoFactura = new javax.swing.JLabel();
        cmbTipo = new javax.swing.JComboBox<>();
        btnAgregar = new javax.swing.JButton();
        btnTerminar = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblProductos = new javax.swing.JTable();
        lblFecha = new javax.swing.JLabel();
        txtFecha = new javax.swing.JTextField();
        lblLocal = new javax.swing.JLabel();
        cmbLocal = new javax.swing.JComboBox<>();
        lblProductos = new javax.swing.JLabel();
        lblCompra = new javax.swing.JLabel();
        btnEliminar = new javax.swing.JButton();
        lblFormaDePago = new javax.swing.JLabel();
        cmbFormaDePago = new javax.swing.JComboBox<>();
        jScrollPane3 = new javax.swing.JScrollPane();
        tblCompras = new javax.swing.JTable();

        lblNumero.setText("Número:");

        lblMonto.setText("Monto:");

        txtNumero.setEditable(false);

        txtMonto.setEditable(false);

        lblTipoFactura.setText("Tipo Factura:");

        cmbTipo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmbTipoActionPerformed(evt);
            }
        });

        btnAgregar.setText("Agregar a la compra");
        btnAgregar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAgregarActionPerformed(evt);
            }
        });

        btnTerminar.setText("Terminar compra");
        btnTerminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnTerminarActionPerformed(evt);
            }
        });

        jScrollPane1.setViewportView(tblProductos);

        lblFecha.setText("Fecha:");

        txtFecha.setEditable(false);

        lblLocal.setText("Local:");

        lblProductos.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        lblProductos.setText("Productos:");

        lblCompra.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        lblCompra.setText("Compra:");

        btnEliminar.setText("Eliminar producto de la compra");
        btnEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEliminarActionPerformed(evt);
            }
        });

        lblFormaDePago.setText("Forma de Pago:");

        jScrollPane3.setViewportView(tblCompras);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane3)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.TRAILING)))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(66, 66, 66)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(lblTipoFactura)
                                    .addComponent(lblLocal)
                                    .addComponent(lblFormaDePago))
                                .addGap(45, 45, 45)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(cmbLocal, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(cmbTipo, javax.swing.GroupLayout.PREFERRED_SIZE, 129, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(cmbFormaDePago, javax.swing.GroupLayout.PREFERRED_SIZE, 264, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(18, 18, 18)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(lblMonto)
                                    .addComponent(lblFecha)
                                    .addComponent(lblNumero))
                                .addGap(35, 35, 35)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(txtFecha)
                                    .addComponent(txtMonto)
                                    .addComponent(txtNumero, javax.swing.GroupLayout.PREFERRED_SIZE, 76, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(310, 310, 310)
                                .addComponent(lblCompra))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(26, 26, 26)
                                .addComponent(btnAgregar, javax.swing.GroupLayout.PREFERRED_SIZE, 139, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(137, 137, 137)
                                        .addComponent(lblProductos))
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(102, 102, 102)
                                        .addComponent(btnEliminar)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 128, Short.MAX_VALUE)
                                        .addComponent(btnTerminar, javax.swing.GroupLayout.PREFERRED_SIZE, 137, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                        .addGap(14, 14, 14)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblTipoFactura)
                    .addComponent(cmbTipo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblNumero)
                    .addComponent(txtNumero, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblFecha)
                    .addComponent(txtFecha, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cmbLocal, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblLocal))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblMonto)
                    .addComponent(txtMonto, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblFormaDePago)
                    .addComponent(cmbFormaDePago, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(lblCompra)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 84, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnTerminar)
                    .addComponent(btnEliminar)
                    .addComponent(btnAgregar))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(lblProductos)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 139, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void cmbTipoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbTipoActionPerformed
        // Poner número de factura según el tipo de factura
        if(cmbTipo.getItemAt(cmbTipo.getSelectedIndex()).name().equals("A")){
            numero=fr.getAll()
                    .stream()
                    .filter(f-> f.getTipo()==Tipo.A)
                    .max(Comparator.comparingInt(Factura::getNumero))
                    .get()
                    .getNumero();
            txtNumero.setText(numero+1+"");
        } else if (cmbTipo.getItemAt(cmbTipo.getSelectedIndex()).name().equals("B")){
            numero=fr.getAll()
                    .stream()
                    .filter(f-> f.getTipo()==Tipo.B)
                    .max(Comparator.comparingInt(Factura::getNumero))
                    .get()
                    .getNumero();
            txtNumero.setText(numero+1+"");
        } else if (cmbTipo.getItemAt(cmbTipo.getSelectedIndex()).name().equals("C")){
            numero=fr.getAll()
                    .stream()
                    .filter(f-> f.getTipo()==Tipo.C)
                    .max(Comparator.comparingInt(Factura::getNumero))
                    .get()
                    .getNumero();
            txtNumero.setText(numero+1+"");
        }
    }//GEN-LAST:event_cmbTipoActionPerformed

    private void btnAgregarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAgregarActionPerformed
        // Evento agregar a la compra
        if(tblProductos.getSelectedRow()==-1){
            JOptionPane.showMessageDialog(this, 
                "Seleccione un producto de la tabla inferior.");
        } else {
        producto.setId(Integer.parseInt(tblProductos.getValueAt(tblProductos.getSelectedRow(), 0)+""));
        producto.setNombre(tblProductos.getValueAt(tblProductos.getSelectedRow(), 1)+"");
        producto.setTipoProducto(TipoProducto.valueOf(tblProductos.getValueAt(tblProductos.getSelectedRow(), 3)+""));
        producto.setPrecio(Double.parseDouble(tblProductos.getValueAt(tblProductos.getSelectedRow(), 4)+""));
        monto+=producto.getPrecio();
        txtMonto.setText(monto+"");
        Detalle detalle = new Detalle(
                factura.getId(), 
                producto.getId(),
                producto.getNombre(),
                producto.getPrecio()
        );
        dr.save(detalle);
        factura.setTipo(Tipo.valueOf(cmbTipo.getItemAt(cmbTipo.getSelectedIndex())+""));
        factura.setFormaDePago(FormaDePago.valueOf(cmbFormaDePago.getItemAt(cmbFormaDePago.getSelectedIndex())+""));
        factura.setMonto(monto);
        factura.setMasIVA(monto+1.21);
        fr.update(factura);
        cargarTblCompras();
        }
    }//GEN-LAST:event_btnAgregarActionPerformed

    private void btnEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEliminarActionPerformed
        // Evento Eliminar
        if(tblCompras.getSelectedRow()==-1){ JOptionPane.showMessageDialog(this, 
                "Seleccione un producto de la tabla superior.");
        } else {
        Detalle detalle = dr.getById(Integer.parseInt(tblCompras.getValueAt(tblCompras.getSelectedRow(), 0)+""));
        dr.remove(detalle);
        monto-=detalle.getPrecio();
        txtMonto.setText(monto+"");
        factura.setMonto(monto);
        factura.setMasIVA(monto+1.21);
        fr.update(factura);
        cargarTblCompras();
        }
    }//GEN-LAST:event_btnEliminarActionPerformed

    private void btnTerminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnTerminarActionPerformed
        // Evento terminar
        if(factura.getMonto()==0){
            fr.remove(factura);
        }
        this.dispose();
    }//GEN-LAST:event_btnTerminarActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAgregar;
    private javax.swing.JButton btnEliminar;
    private javax.swing.JButton btnTerminar;
    private javax.swing.JComboBox<FormaDePago> cmbFormaDePago;
    private javax.swing.JComboBox<Local> cmbLocal;
    private javax.swing.JComboBox<Tipo> cmbTipo;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JLabel lblCompra;
    private javax.swing.JLabel lblFecha;
    private javax.swing.JLabel lblFormaDePago;
    private javax.swing.JLabel lblLocal;
    private javax.swing.JLabel lblMonto;
    private javax.swing.JLabel lblNumero;
    private javax.swing.JLabel lblProductos;
    private javax.swing.JLabel lblTipoFactura;
    private javax.swing.JTable tblCompras;
    private javax.swing.JTable tblProductos;
    private javax.swing.JTextField txtFecha;
    private javax.swing.JTextField txtMonto;
    private javax.swing.JTextField txtNumero;
    // End of variables declaration//GEN-END:variables
}
