package ar.org.centro8.curso.java.entities;

import ar.org.centro8.curso.java.enums.Barrio;

public class Local {

    private int id;
    private String direccion;
    private Barrio barrio;
    private int cantidadEmpleados;

    public Local() {
    }

    public Local(String direccion, Barrio barrio, int cantidadEmpleados) {
        this.direccion = direccion;
        this.barrio = barrio;
        this.cantidadEmpleados = cantidadEmpleados;
    }

    public Local(int id, String direccion, Barrio barrio, int cantidadEmpleados) {
        this.id = id;
        this.direccion = direccion;
        this.barrio = barrio;
        this.cantidadEmpleados = cantidadEmpleados;
    }

    @Override
    public String toString() {
        return "Local{" + "id=" + id + ", direccion=" + direccion + ", barrio=" 
                + barrio + ", cantidadEmpleados=" + cantidadEmpleados + '}';
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public Barrio getBarrio() {
        return barrio;
    }

    public void setBarrio(Barrio barrio) {
        this.barrio = barrio;
    }

    public int getCantidadEmpleados() {
        return cantidadEmpleados;
    }

    public void setCantidadEmpleados(int cantidadEmpleados) {
        this.cantidadEmpleados = cantidadEmpleados;
    }
    
    
        
}