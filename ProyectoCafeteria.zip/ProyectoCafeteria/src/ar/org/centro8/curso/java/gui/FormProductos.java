package ar.org.centro8.curso.java.gui;


import ar.org.centro8.curso.java.connectors.Connector;
import ar.org.centro8.curso.java.entities.Producto;
import ar.org.centro8.curso.java.enums.TipoProducto;
import ar.org.centro8.curso.java.repositories.interfaces.I_ProductoRepository;
import ar.org.centro8.curso.java.repositories.jdbc.ProductoRepository;
import ar.org.centro8.curso.java.utils.swing.Table;
import ar.org.centro8.curso.java.utils.swing.Validator;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class FormProductos extends javax.swing.JInternalFrame {
    private I_ProductoRepository pr = new ProductoRepository(Connector.getConnection()); 
    
    public FormProductos() {
        super(
                "Productos",                    //title
                true,                           //resizable
                true,                           //closable
                true,                           //maximizable
                true                            //iconable
        );
        initComponents();
        cargarElementos();
    }

    private void cargarElementos() {
        // cargar cmbTipoProducto
        cmbTipoProducto.removeAllItems();
        for (TipoProducto tp : TipoProducto.values()) cmbTipoProducto.addItem(tp);
        
        // cargar tblProductos
        new Table().cargar(tblProductos, pr.getAll());
        
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        lblNombre = new javax.swing.JLabel();
        lblDescripcion = new javax.swing.JLabel();
        lblTipoProducto = new javax.swing.JLabel();
        lblPrecio = new javax.swing.JLabel();
        txtNombre = new javax.swing.JTextField();
        txtDescripcion = new javax.swing.JTextField();
        cmbTipoProducto = new javax.swing.JComboBox<>();
        txtPrecio = new javax.swing.JTextField();
        lblConfirmacion = new javax.swing.JLabel();
        btnIngresar = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblProductos = new javax.swing.JTable();
        btnEliminar = new javax.swing.JButton();
        btnModificar = new javax.swing.JButton();

        setTitle("Productos");

        lblNombre.setText("Nombre:");

        lblDescripcion.setText("Descripción:");

        lblTipoProducto.setText("Tipo de producto:");

        lblPrecio.setText("Precio:");

        txtNombre.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtNombreKeyReleased(evt);
            }
        });

        txtDescripcion.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtDescripcionKeyReleased(evt);
            }
        });

        lblConfirmacion.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        btnIngresar.setText("Ingresar ");
        btnIngresar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnIngresarActionPerformed(evt);
            }
        });

        tblProductos.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jScrollPane1.setViewportView(tblProductos);

        btnEliminar.setText("Eliminar");
        btnEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEliminarActionPerformed(evt);
            }
        });

        btnModificar.setText("Modificar");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1)
                .addContainerGap())
            .addGroup(layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblConfirmacion, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lblNombre)
                            .addComponent(lblPrecio)
                            .addComponent(lblTipoProducto)
                            .addComponent(lblDescripcion)
                            .addComponent(btnIngresar))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 194, Short.MAX_VALUE)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(txtNombre)
                                    .addComponent(txtDescripcion)
                                    .addComponent(cmbTipoProducto, 0, 175, Short.MAX_VALUE)
                                    .addComponent(txtPrecio)))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(85, 85, 85)
                                .addComponent(btnModificar)
                                .addGap(108, 108, 108)
                                .addComponent(btnEliminar)))))
                .addGap(34, 34, 34))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblNombre)
                    .addComponent(txtNombre, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblDescripcion)
                    .addComponent(txtDescripcion, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblTipoProducto)
                    .addComponent(cmbTipoProducto, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblPrecio)
                    .addComponent(txtPrecio, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(11, 11, 11)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnIngresar)
                    .addComponent(btnEliminar)
                    .addComponent(btnModificar))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(lblConfirmacion, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 174, Short.MAX_VALUE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnIngresarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnIngresarActionPerformed
        // Evento Ingresar
        if(!validar()) return;
        Producto producto = new Producto(
                txtNombre.getText(), 
                txtDescripcion.getText(), 
                cmbTipoProducto.getItemAt(cmbTipoProducto.getSelectedIndex()), 
                Double.parseDouble(txtPrecio.getText())
        );
        pr.save(producto);
        cargarElementos();
        txtNombre.setText("");
        txtDescripcion.setText("");
        txtPrecio.setText("");
        lblConfirmacion.setText("El producto nro"+producto.getId()+" se guardó en la base.");
    }//GEN-LAST:event_btnIngresarActionPerformed

    private void txtNombreKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtNombreKeyReleased
        //Evento Buscar por Nombre
        new Table().cargar(tblProductos, pr.getLikeNombre(txtNombre.getText()));
    }//GEN-LAST:event_txtNombreKeyReleased

    private void txtDescripcionKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtDescripcionKeyReleased
        // Evento Buscar por Descripcion
        new Table().cargar(tblProductos, pr.getLikeDescripcion(txtDescripcion.getText()));
    }//GEN-LAST:event_txtDescripcionKeyReleased

    private void btnEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEliminarActionPerformed
        // Evento Eliminar
        int fila=tblProductos.getSelectedRow();
        if(fila==-1) return;
        int id = (int) tblProductos.getValueAt(fila, 0);
        if(JOptionPane.showConfirmDialog(this, "¿Desea eliminar el producto id:"+id+"?")!=0) return;
        pr.remove(pr.getById(id));
        cargarElementos();
        txtNombre.setText("");
        txtDescripcion.setText("");
        txtPrecio.setText("");
        lblConfirmacion.setText("El producto seleccionado se eliminó de la base.");
    }//GEN-LAST:event_btnEliminarActionPerformed
    
    private boolean validar(){
        if(!new Validator(txtNombre).length(3, 25))       return false;
        if(!new Validator(txtDescripcion).length(3, 140)) return false;
        return true;
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnEliminar;
    private javax.swing.JButton btnIngresar;
    private javax.swing.JButton btnModificar;
    private javax.swing.JComboBox<TipoProducto> cmbTipoProducto;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lblConfirmacion;
    private javax.swing.JLabel lblDescripcion;
    private javax.swing.JLabel lblNombre;
    private javax.swing.JLabel lblPrecio;
    private javax.swing.JLabel lblTipoProducto;
    private javax.swing.JTable tblProductos;
    private javax.swing.JTextField txtDescripcion;
    private javax.swing.JTextField txtNombre;
    private javax.swing.JTextField txtPrecio;
    // End of variables declaration//GEN-END:variables
}
