package ar.org.centro8.curso.java.test;

import ar.org.centro8.curso.java.connectors.Connector;
import ar.org.centro8.curso.java.entities.Detalle;
import ar.org.centro8.curso.java.entities.Empleado;
import ar.org.centro8.curso.java.entities.Factura;
import ar.org.centro8.curso.java.entities.Local;
import ar.org.centro8.curso.java.entities.Producto;
import ar.org.centro8.curso.java.enums.Barrio;
import ar.org.centro8.curso.java.enums.FormaDePago;
import ar.org.centro8.curso.java.enums.Posicion;
import ar.org.centro8.curso.java.enums.Tipo;
import ar.org.centro8.curso.java.enums.TipoProducto;
import ar.org.centro8.curso.java.repositories.interfaces.I_DetalleRepository;
import ar.org.centro8.curso.java.repositories.interfaces.I_EmpleadoRepository;
import ar.org.centro8.curso.java.repositories.interfaces.I_FacturaRepository;
import ar.org.centro8.curso.java.repositories.interfaces.I_LocalRepository;
import ar.org.centro8.curso.java.repositories.interfaces.I_ProductoRepository;
import ar.org.centro8.curso.java.repositories.jdbc.DetalleRepository;
import ar.org.centro8.curso.java.repositories.jdbc.EmpleadoRepository;
import ar.org.centro8.curso.java.repositories.jdbc.FacturaRepository;
import ar.org.centro8.curso.java.repositories.jdbc.LocalRepository;
import ar.org.centro8.curso.java.repositories.jdbc.ProductoRepository;

public class TestRepositories {

    public static void main(String[] args) {
        
        System.out.println("************Tabla Locales************");
        I_LocalRepository lr = new LocalRepository(Connector.getConnection());
        lr.getAll().forEach(System.out::println);
        /*
        System.out.println("************Local nuevo************");
        Local local = new Local("San Juan 750", Barrio.SAN_TELMO, 3);
        lr.save(local);
        System.out.println(local.toString());
        System.out.println("************Aumentarle un empleado************");
        local.setCantidadEmpleados(4);
        lr.update(local);
        lr.getAll().forEach(System.out::println);
        */
        System.out.println("************Borrar local 8************");
        lr.remove(lr.getById(10));
        lr.getAll().forEach(System.out::println);
        
        System.out.println("************Mostrar local con id=2************");
        System.out.println(lr.getById(2));
        
        System.out.println("************Mostrar locales barrio San Telmo************");
        lr.getByBarrio(Barrio.SAN_TELMO).forEach(System.out::println);
        
        System.out.println("************Mostrar locales con direccion like 'de'************");
        lr.getLikeDireccion("de").forEach(System.out::println);
        
        System.out.println("************Tabla Empleados************");
        I_EmpleadoRepository er = new EmpleadoRepository(Connector.getConnection());
        er.getAll().forEach(System.out::println);
        /*
        System.out.println("************Ingreso los empleados del local id=5************");
        Empleado e1=new Empleado(5, "Jazmin", "Aranda", 20, Posicion.EMPLEADO);
        er.save(e1);
        Empleado e2=new Empleado(5, "Giovanni", "Schaeffer", 18, Posicion.DELIVERY);
        er.save(e2);
        Empleado e3=new Empleado(5, "Lujan", "Benitez", 25, Posicion.EMPLEADO);
        er.save(e3);
        Empleado e4=new Empleado(5, "Adrian", "Flores", 20, Posicion.ENCARGADO);
        er.save(e4);
        er.getByLocal(lr.getById(5)).forEach(System.out::println);
        */
        System.out.println("************Tabla actualizada************");
        er.getAll().forEach(System.out::println);
        
        System.out.println("************Mostrar empleado id=2************");
        System.out.println(er.getById(2));
        
        System.out.println("************Mostrar empleados donde apellido like 'ez'************");
        er.getLikeApellido("ez").forEach(System.out::println);
        
        System.out.println("************Mostrar empleados donde apellido like 'ez"
                + " y nombre like 'ma'************");
        er.getLikeApellidoAndNombre("ez", "ma").forEach(System.out::println);
        
        System.out.println("************Mostrar los empleados del local id=4************");
        er.getByLocal(lr.getById(4)).forEach(System.out::println);
        
        System.out.println("************Mostrar los registros de posición ENCARGADO************");
        er.getByPosicion(Posicion.ENCARGADO).forEach(System.out::println);
        
        
        System.out.println("************Tabla Productos************");
        I_ProductoRepository pr = new ProductoRepository(Connector.getConnection());
        pr.getAll().forEach(System.out::println);
       /*
        System.out.println("************Ingreso un nuevo producto************");
        Producto producto=new Producto("Choco chips", "Muffin de chocolate con chispas de chocolate", 
                            TipoProducto.COMIDA, 170);
        pr.save(producto);
        
        System.out.println("************Tabla actualizada************");
        pr.getAll().forEach(System.out::println);
        */        
        System.out.println("************Mostrar nombre like 'ch'************");
        pr.getLikeNombre("ch").forEach(System.out::println);
        
        System.out.println("************Mostrar nombre like 'ch' y descripcion like 'ch'************");
        pr.getLikeNombreAndDescripcion("ch", "ch").forEach(System.out::println);
        
        System.out.println("************Mostrar descripcion like 'espresso'************");
        pr.getLikeDescripcion("espresso").forEach(System.out::println);
        /*
        System.out.println("************Eliminar ingresos repetidos por id************");
        pr.remove(pr.getById(21));
        pr.remove(pr.getById(22));
        pr.remove(pr.getById(23));
        pr.remove(pr.getById(24));
        pr.remove(pr.getById(25));
        pr.getAll().forEach(System.out::println);
        */
        System.out.println("************Mostrar productos where tipoProducto=GRANOS************");
        pr.getByTipoProducto(TipoProducto.GRANOS).forEach(System.out::println);
        
        System.out.println("************Tabla Facturas************");
        I_FacturaRepository fr = new FacturaRepository(Connector.getConnection());
        fr.getAll().forEach(System.out::println);
        /*
        System.out.println("************Nueva factura************");
        Factura factura = new Factura(Tipo.C, 0001, 5, 180, 217.8, FormaDePago.MERCADOPAGO, "2021-05-25");
        fr.save(factura);
        */
        System.out.println("************Tabla Facturas actualizada************");
        fr.getAll().forEach(System.out::println);
        
        System.out.println("************Mostrar Facturas por fecha************");
        fr.getLikeFecha("2021-05-17").forEach(System.out::println);
        
        System.out.println("************Mostrar Facturas por fecha y local************");
        fr.getByFechaAndLocal("2021-05-17", lr.getById(2)).forEach(System.out::println);
        
        System.out.println("************Mostrar Facturas por forma de pago************");
        fr.getByFormaDePago(FormaDePago.DEBITO).forEach(System.out::println);
        
        System.out.println("************Mostrar Facturas por forma de pago y local************");
        fr.getByFormaDePagoAndLocal(FormaDePago.MERCADOPAGO, lr.getById(1));
        
        System.out.println("************Mostrar Facturas por tipo y numero************");
        fr.getByTipoAndNumero(Tipo.A, 1).forEach(System.out::println);
        
        System.out.println("************Mostrar Facturas por monto mayor que 314************");
        fr.getByMontoMayorQue(314).forEach(System.out::println);
        
        System.out.println("************Eliminar por id************");
        fr.remove(fr.getById(7));
        
        System.out.println("************Mostrar tabla Facturas actualizada************");
        fr.getAll().forEach(System.out::println);
        
        
        System.out.println("************Tabla Detalles************");
        I_DetalleRepository dr = new DetalleRepository(Connector.getConnection());
        dr.getAll().forEach(System.out::println);
        
        System.out.println("************Creo un nuevo registro************");
        Detalle detalle = new Detalle(6, 9, 180);
        dr.save(detalle);
        System.out.println(detalle.toString());
        
        System.out.println("************Tabla Detalles actualizada************");
        dr.getAll().forEach(System.out::println);
        
        System.out.println("************Motrar Detalles por idFactura=$************");
        dr.getByFactura(fr.getById(4)).forEach(System.out::println);
        
        System.out.println("************Mostrar Detalles por idFactura=3 e idProducto=2************");
        dr.getByFacturaAndProducto(fr.getById(3), pr.getById(2)).forEach(System.out::println);
        
        System.out.println("************Mostrar Detalles por idProducto=3************");
        dr.getByProducto(pr.getById(3)).forEach(System.out::println);
        
        System.out.println("************Mostrar Detalles por precio=180************");
        dr.getByPrecio(180).forEach(System.out::println);
        /*
        System.out.println("************Eliminar de Detalles por id=12************");
        dr.remove(dr.getById(12));
        */
        System.out.println("************Tabla Detalles actualizada************");
        dr.getAll().forEach(System.out::println);
        
    }

    
}