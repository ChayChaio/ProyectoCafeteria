package ar.org.centro8.curso.java.repositories.interfaces;

import ar.org.centro8.curso.java.entities.Empleado;
import ar.org.centro8.curso.java.entities.Local;
import ar.org.centro8.curso.java.enums.Barrio;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public interface I_LocalRepository {

    void save(Local local);         
    void remove(Local local);       
    void update(Local local);      
    List<Local>getAll();           
    default Local getById(int id){
        return getAll()
                .stream()
                .filter(l->l.getId()==id)
                .findAny()
                .orElse(new Local());
    }
    default List<Local> getByBarrio(Barrio barrio){
        if(barrio==null) return new ArrayList();
        return getAll()
                .stream()
                .filter(l->l.getBarrio()==barrio)
                .collect(Collectors.toList());
    }
    
    default List<Local> getByLikeDireccion(String direccion){
        if(direccion==null) return new ArrayList();
        return getAll()
                .stream()
                .filter(l->l.getDireccion().toLowerCase().contains(direccion.toLowerCase()))
                .collect(Collectors.toList());
    }
    
}
