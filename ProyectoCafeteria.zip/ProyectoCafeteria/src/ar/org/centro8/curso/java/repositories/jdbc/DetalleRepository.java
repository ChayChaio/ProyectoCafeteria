package ar.org.centro8.curso.java.repositories.jdbc;

import ar.org.centro8.curso.java.entities.Detalle;
import ar.org.centro8.curso.java.repositories.interfaces.I_DetalleRepository;
import java.util.List;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

public class DetalleRepository implements I_DetalleRepository{

    Connection conn;

    public DetalleRepository(Connection conn) {
        this.conn = conn;
    }
    
    @Override
    public void save(Detalle detalle) {
        if(detalle==null) return;
        try (PreparedStatement ps=conn.prepareStatement("insert into detalles "
                + "(idFactura, idProducto, precio) values (?,?,?)",
                PreparedStatement.RETURN_GENERATED_KEYS)){
            ps.setInt(1, detalle.getIdFactura());
            ps.setInt(2, detalle.getIdProducto());
            ps.setDouble(3, detalle.getPrecio());
            ps.execute();
            ResultSet rs=ps.getGeneratedKeys();
            if(rs.next())   detalle.setId(rs.getInt(1));
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    @Override
    public void remove(Detalle detalle) {
        if(detalle==null) return;
        try (PreparedStatement ps=conn.prepareStatement("delete from detalles where id=?")){
            ps.setInt(1, detalle.getId());
            ps.execute();
            
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    @Override
    public void update(Detalle detalle) {
        if(detalle==null) return;
        try (PreparedStatement ps=conn.prepareStatement("update detalles set "
                + "set idFactura=?, idProducto=?, precio=? where id=?")){
            ps.setInt(1, detalle.getIdFactura());
            ps.setInt(2, detalle.getIdProducto());
            ps.setDouble(3, detalle.getPrecio());
            ps.setInt(4, detalle.getId());
            ps.execute();
            ResultSet rs=ps.getGeneratedKeys();
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    @Override
    public List<Detalle> getAll() {
        List<Detalle> list = new ArrayList();
        try (ResultSet rs=conn.createStatement().executeQuery("select * from detalles")){
            while (rs.next()) {
                list.add(new Detalle(
                        rs.getInt("id"),
                        rs.getInt("idFactura"),
                        rs.getInt("idProducto"),
                        rs.getDouble("precio")));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }

}