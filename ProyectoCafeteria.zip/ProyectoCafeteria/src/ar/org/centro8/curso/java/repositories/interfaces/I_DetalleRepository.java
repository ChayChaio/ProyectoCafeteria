package ar.org.centro8.curso.java.repositories.interfaces;

import ar.org.centro8.curso.java.entities.Detalle;
import ar.org.centro8.curso.java.entities.Factura;
import ar.org.centro8.curso.java.entities.Producto;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public interface I_DetalleRepository {

    void save(Detalle detalle);       
    void remove(Detalle detalle);     
    void update(Detalle detalle);     
    List<Detalle>getAll();            
    default Detalle getById(int id){
        return getAll()
                .stream()
                .filter(d->d.getId()==id)
                .findAny()
                .orElse(new Detalle());
    }

    default List<Detalle> getByProducto(Producto producto){
        if(producto==null) return new ArrayList();
        return getAll()
                .stream()
                .filter(d->d.getIdProducto()==producto.getId())
                .collect(Collectors.toList());
    }
    
    default List<Detalle> getByFactura (Factura factura){
        if(factura==null) return new ArrayList();
        return getAll()
                .stream()
                .filter(d->d.getIdFactura()==factura.getId())
                .collect(Collectors.toList());
    }
    
    default List<Detalle> getByFacturaAndProducto(Factura factura, Producto producto){
        if(factura==null || producto==null) return new ArrayList();
        return getAll()
                .stream()
                .filter(d->d.getIdFactura()==factura.getId()
                && d.getIdProducto()==producto.getId())
                .collect(Collectors.toList());
    }
    
    default List<Detalle> getByPrecio (double precio){
        if (precio==0) return new ArrayList();
        return getAll()
                .stream()
                .filter(d->d.getPrecio()==precio)
                .collect(Collectors.toList());
    }
    
}
