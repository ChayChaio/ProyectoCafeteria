package ar.org.centro8.curso.java.repositories.interfaces;

import ar.org.centro8.curso.java.entities.Empleado;
import ar.org.centro8.curso.java.entities.Local;
import ar.org.centro8.curso.java.enums.Posicion;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public interface I_EmpleadoRepository {

    void save(Empleado empleado);         
    void remove(Empleado empleado);       
    void update(Empleado empleado);       
    List<Empleado>getAll();            
    default Empleado getById(int id){
        return getAll()
                .stream()
                .filter(e->e.getId()==id)
                .findAny()
                .orElse(new Empleado());
    }
    default List<Empleado> getLikeApellido(String apellido){
        if(apellido==null) return new ArrayList();
        return getAll()
                .stream()
                .filter(e->e.getApellido().toLowerCase().contains(apellido.toLowerCase()))
                .collect(Collectors.toList());
    }
    default List<Empleado> getLikeApellidoAndNombre(String apellido, String nombre){
        if(apellido==null || nombre==null) return new ArrayList();
        return getAll()
                .stream()
                .filter(e->e.getApellido().toLowerCase().contains(apellido.toLowerCase())
                && e.getNombre().toLowerCase().contains(nombre.toLowerCase()))
                .collect(Collectors.toList());
    }
    
    default List<Empleado> getByLocal(Local local) {
        if(local==null) return new ArrayList();
        return getAll()
                .stream()
                .filter(e->e.getIdLocal()==local.getId())
                .collect(Collectors.toList());
    }
    
    default List<Empleado> getByPosicion (Posicion posicion) {
        if(posicion==null) return new ArrayList();
        return getAll()
                .stream()
                .filter(e->e.getPosicion()==posicion)
                .collect(Collectors.toList());
    }
    
}
