package ar.org.centro8.curso.java.utils.swing;

import javax.swing.JOptionPane;
import javax.swing.JTextField;

public class Validator {

    private JTextField txt;

    public Validator(JTextField txt) {
        this.txt = txt;
    }
    
    private boolean error(String msj){
        txt.requestFocus();
        JOptionPane.showMessageDialog(txt, msj, "Error", 0);
        return false;
    }
    
    public boolean length(int min, int max){
        if(txt.getText().length()>=min && txt.getText().length()<=max) return true;
        return error("El texto debe tener entre " + min + " y " + max + " caracteres.");
    }
    
}