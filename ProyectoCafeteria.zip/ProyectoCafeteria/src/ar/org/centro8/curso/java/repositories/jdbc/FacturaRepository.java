package ar.org.centro8.curso.java.repositories.jdbc;

import ar.org.centro8.curso.java.entities.Factura;
import ar.org.centro8.curso.java.enums.FormaDePago;
import ar.org.centro8.curso.java.enums.Tipo;
import ar.org.centro8.curso.java.repositories.interfaces.I_FacturaRepository;
import java.util.List;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

public class FacturaRepository implements I_FacturaRepository{

    Connection conn;

    public FacturaRepository(Connection conn) {
        this.conn = conn;
    }
    
    @Override
    public void save(Factura factura) {
        if(factura==null) return;
        try (PreparedStatement ps=conn.prepareStatement("insert into facturas "
                + "(tipo, numero, idLocal, monto, masIVA, formaDePago, fecha) "
                + "values (?, ?, ?, ?, ?, ?, ?)",
                PreparedStatement.RETURN_GENERATED_KEYS)){
            ps.setString(1, factura.getTipo()+"");
            ps.setInt(2, factura.getNumero());
            ps.setInt(3, factura.getIdLocal());
            ps.setDouble(4, factura.getMonto());
            ps.setDouble(5, factura.getMasIVA());
            ps.setString(6, factura.getFormaDePago()+"");
            ps.setString(7, factura.getFecha());
            ps.execute();
            ResultSet rs=ps.getGeneratedKeys();
            if(rs.next()) factura.setId(rs.getInt(1));
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    @Override
    public void remove(Factura factura) {
        if(factura==null) return;
        try (PreparedStatement ps=conn.prepareStatement("delete from facturas where id=?")){
            ps.setInt(1, factura.getId());
            ps.execute();
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    @Override
    public void update(Factura factura) {
        if(factura==null) return;
        try (PreparedStatement ps=conn.prepareStatement("update facturas set "
                + "tipo=?, numero=?, idLocal=?, monto=?, masIVA=?, formaDePago=?, fecha=? "
                + "where id=?")){
            ps.setString(1, factura.getTipo()+"");
            ps.setInt(2, factura.getNumero());
            ps.setInt(3, factura.getIdLocal());
            ps.setDouble(4, factura.getMonto());
            ps.setDouble(5, factura.getMasIVA());
            ps.setString(6, factura.getFormaDePago()+"");
            ps.setString(7, factura.getFecha());
            ps.setInt(8, factura.getId());
            ps.execute();
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    @Override
    public List<Factura> getAll() {
        List<Factura> list = new ArrayList();
        try (ResultSet rs=conn.createStatement().executeQuery("select * from facturas")){
            while (rs.next()) {
                list.add(new Factura(
                        rs.getInt("id"),
                        Tipo.valueOf(rs.getString("tipo")),
                        rs.getInt("numero"),
                        rs.getInt("idLocal"),
                        rs.getDouble("monto"),
                        rs.getDouble("masIVA"),
                        FormaDePago.valueOf(rs.getString("formaDePago")),
                        rs.getString("fecha")));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }

}