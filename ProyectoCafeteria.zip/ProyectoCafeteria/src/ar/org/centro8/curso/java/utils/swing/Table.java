package ar.org.centro8.curso.java.utils.swing;

import java.lang.reflect.Field;
import java.util.List;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

public class Table <E> {

    public void cargar(JTable tbl, List<E> list){
        if(tbl==null) return;
        DefaultTableModel modelo = new DefaultTableModel();
        tbl.setModel(modelo);
        if(list==null || list.isEmpty()) return;
        E e = list.get(0);
        Field[] campos= e.getClass().getDeclaredFields();
        for(Field f:campos) modelo.addColumn(f.getName());
        for(E ee:list){
            Object[] registro=new Object[campos.length];
            for(int i=0; i<campos.length;i++){
                Field f=campos[i];
                String metodo="get"+f.getName().substring(0,1).toUpperCase()+
                        f.getName().substring(1);
                //System.out.println(metodo);
                try {
                    registro[i]=e.getClass().getMethod(metodo, null).invoke(ee, null);
                } catch (Exception ex) {ex.printStackTrace();}
            }
            modelo.addRow(registro);
        }
    }
    
}