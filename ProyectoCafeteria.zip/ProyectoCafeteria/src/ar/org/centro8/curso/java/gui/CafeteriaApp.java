package ar.org.centro8.curso.java.gui;

import javax.swing.JDesktopPane;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

public class CafeteriaApp extends javax.swing.JFrame {

    public CafeteriaApp() {
        initComponents();
        this.setExtendedState(JFrame.MAXIMIZED_BOTH);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        desktop = new javax.swing.JDesktopPane();
        jMenuBar1 = new javax.swing.JMenuBar();
        mnuEntidades = new javax.swing.JMenu();
        mniProductos = new javax.swing.JMenuItem();
        mniFacturas = new javax.swing.JMenuItem();
        mniEmpleados = new javax.swing.JMenuItem();
        mniLocales = new javax.swing.JMenuItem();
        jMenu2 = new javax.swing.JMenu();
        mniAcerca = new javax.swing.JMenuItem();
        mniSalir = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Proyecto Cafeteria");

        javax.swing.GroupLayout desktopLayout = new javax.swing.GroupLayout(desktop);
        desktop.setLayout(desktopLayout);
        desktopLayout.setHorizontalGroup(
            desktopLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        desktopLayout.setVerticalGroup(
            desktopLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 278, Short.MAX_VALUE)
        );

        mnuEntidades.setText("Entidades");

        mniProductos.setText("Productos");
        mniProductos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mniProductosActionPerformed(evt);
            }
        });
        mnuEntidades.add(mniProductos);

        mniFacturas.setText("Facturas");
        mniFacturas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mniFacturasActionPerformed(evt);
            }
        });
        mnuEntidades.add(mniFacturas);

        mniEmpleados.setText("Empleados");
        mniEmpleados.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mniEmpleadosActionPerformed(evt);
            }
        });
        mnuEntidades.add(mniEmpleados);

        mniLocales.setText("Locales");
        mniLocales.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mniLocalesActionPerformed(evt);
            }
        });
        mnuEntidades.add(mniLocales);

        jMenuBar1.add(mnuEntidades);

        jMenu2.setText("Opciones");

        mniAcerca.setText("Acerca de...");
        mniAcerca.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mniAcercaActionPerformed(evt);
            }
        });
        jMenu2.add(mniAcerca);

        mniSalir.setText("Salir");
        mniSalir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mniSalirActionPerformed(evt);
            }
        });
        jMenu2.add(mniSalir);

        jMenuBar1.add(jMenu2);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(desktop)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(desktop)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void mniProductosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mniProductosActionPerformed
        //Evento Ventana Productos
        FormProductos fp = new FormProductos();
        desktop.add(fp);
        fp.setVisible(true);
    }//GEN-LAST:event_mniProductosActionPerformed

    private void mniSalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mniSalirActionPerformed
        //Evento Salir
        System.exit(0);
    }//GEN-LAST:event_mniSalirActionPerformed

    private void mniFacturasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mniFacturasActionPerformed
        //Evento Ventana Facturas
        FormFacturas ff = new FormFacturas();
        desktop.add(ff);
        ff.setVisible(true);
    }//GEN-LAST:event_mniFacturasActionPerformed

    private void mniEmpleadosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mniEmpleadosActionPerformed
        //Evento Ventana Empleados
        FormEmpleados fe = new FormEmpleados();
        desktop.add(fe);
        fe.setVisible(true);
    }//GEN-LAST:event_mniEmpleadosActionPerformed

    private void mniLocalesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mniLocalesActionPerformed
        //Evento Ventana Locales
        FormLocales fl = new FormLocales();
        desktop.add(fl);
        fl.setVisible(true);
    }//GEN-LAST:event_mniLocalesActionPerformed

    private void mniAcercaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mniAcercaActionPerformed
        //Evento Acerca
        JOptionPane.showMessageDialog(this, "Trabajo final de Rosario Díaz para "
                + "Java - Programación Orientada a Objetos, en CFP8. Turno noche, "
                + "con el profesor Carlos Ríos.");
    }//GEN-LAST:event_mniAcercaActionPerformed
    public static void main(String args[]) {

        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(CafeteriaApp.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(CafeteriaApp.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(CafeteriaApp.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(CafeteriaApp.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>


        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new CafeteriaApp().setVisible(true);
            }
        });
    }

    public JDesktopPane getDesktop() {
        return desktop;
    }
    
    

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JDesktopPane desktop;
    private javax.swing.JMenu jMenu2;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JMenuItem mniAcerca;
    private javax.swing.JMenuItem mniEmpleados;
    private javax.swing.JMenuItem mniFacturas;
    private javax.swing.JMenuItem mniLocales;
    private javax.swing.JMenuItem mniProductos;
    private javax.swing.JMenuItem mniSalir;
    private javax.swing.JMenu mnuEntidades;
    // End of variables declaration//GEN-END:variables
}
