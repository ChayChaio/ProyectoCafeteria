package ar.org.centro8.curso.java.enums;
public enum FormaDePago {

    EFECTIVO,
    CREDITO,
    DEBITO,
    TRANSFERENCIA,
    MERCADOPAGO
    
}
