package ar.org.centro8.curso.java.gui;

import ar.org.centro8.curso.java.connectors.Connector;
import ar.org.centro8.curso.java.entities.Local;
import ar.org.centro8.curso.java.enums.Barrio;
import ar.org.centro8.curso.java.repositories.interfaces.I_EmpleadoRepository;
import ar.org.centro8.curso.java.repositories.interfaces.I_LocalRepository;
import ar.org.centro8.curso.java.repositories.jdbc.EmpleadoRepository;
import ar.org.centro8.curso.java.repositories.jdbc.LocalRepository;
import ar.org.centro8.curso.java.utils.swing.Table;
import ar.org.centro8.curso.java.utils.swing.Validator;
import java.sql.Connection;
import javax.swing.JOptionPane;

public class FormLocales extends javax.swing.JInternalFrame {

    private I_LocalRepository lr = new LocalRepository(Connector.getConnection());
    private I_EmpleadoRepository er = new EmpleadoRepository(Connector.getConnection());
    
    public FormLocales() {
        super(
                "Locales",                      //title
                true,                           //resizable
                true,                           //closable
                true,                           //maximizable
                true                            //iconable
        );
        initComponents();
        cargar();
    }

    private void cargar() {
        // Cargar cmbBarrio
        cmbBarrio.removeAllItems();
        for(Barrio b : Barrio.values()) cmbBarrio.addItem(b);
        // Cargar tblLocales
        new Table<Local>().cargar(tblLocales, lr.getAll());
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        lblDireccion = new javax.swing.JLabel();
        lblBarrio = new javax.swing.JLabel();
        txtDireccion = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblLocales = new javax.swing.JTable();
        btnAgregarLocal = new javax.swing.JButton();
        btnListarEmpleados = new javax.swing.JButton();
        cmbBarrio = new javax.swing.JComboBox<>();
        jButton1 = new javax.swing.JButton();
        lblConfirmacion = new javax.swing.JLabel();

        setTitle("Locales");

        lblDireccion.setText("Dirección:");

        lblBarrio.setText("Barrio:");

        txtDireccion.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtDireccionKeyReleased(evt);
            }
        });

        jScrollPane1.setViewportView(tblLocales);

        btnAgregarLocal.setText("Agregar nuevo local");
        btnAgregarLocal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAgregarLocalActionPerformed(evt);
            }
        });

        btnListarEmpleados.setText("Listar Empleados");
        btnListarEmpleados.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnListarEmpleadosActionPerformed(evt);
            }
        });

        cmbBarrio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmbBarrioActionPerformed(evt);
            }
        });

        jButton1.setText("Eliminar local");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        lblConfirmacion.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(24, 24, 24)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lblDireccion)
                            .addComponent(lblBarrio))
                        .addGap(129, 129, 129)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtDireccion)
                            .addComponent(cmbBarrio, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 385, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(btnListarEmpleados)
                                .addGap(16, 16, 16)
                                .addComponent(btnAgregarLocal, javax.swing.GroupLayout.PREFERRED_SIZE, 121, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(jButton1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addComponent(lblConfirmacion, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblDireccion)
                    .addComponent(txtDireccion, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblBarrio)
                    .addComponent(cmbBarrio, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnAgregarLocal)
                    .addComponent(btnListarEmpleados)
                    .addComponent(jButton1))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(lblConfirmacion, javax.swing.GroupLayout.DEFAULT_SIZE, 48, Short.MAX_VALUE)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txtDireccionKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtDireccionKeyReleased
        // Buscar por direccion
        if (txtDireccion.getText()=="" || txtDireccion.getText().isEmpty()) {
            cargar();
        } else {
            new Table<Local>().cargar(tblLocales, lr.getLikeDireccion(txtDireccion.getText()));
        }
    }//GEN-LAST:event_txtDireccionKeyReleased

    private void btnAgregarLocalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAgregarLocalActionPerformed
        // Evento Agregar local
        if(!validar()) return;
        
            Local local = new Local(
                    txtDireccion.getText(), 
                    Barrio.valueOf(cmbBarrio.getItemAt(cmbBarrio.getSelectedIndex())+""), 
                    0
            );
                lr.save(local);
                limpiar();
                cargar();
                JOptionPane.showMessageDialog(null, "El local creado no tiene empleados. "
                    + "Seleccionar el local en la tabla y clickear el botón Listar Empleados."
                        , "Alerta", JOptionPane.INFORMATION_MESSAGE);    
    }//GEN-LAST:event_btnAgregarLocalActionPerformed

    private void limpiar() {
        lblConfirmacion.setText("");
        txtDireccion.setText("");
        txtDireccion.requestFocus();
    }

    private void btnListarEmpleadosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnListarEmpleadosActionPerformed
        // Evento abrir ventana empleados
        if(tblLocales.getSelectedRow()==-1) JOptionPane.showMessageDialog(this, 
                "Seleccione un local de la tabla.");
        int fila=tblLocales.getSelectedRow();
        if(fila==-1) return;
        int id = (int) tblLocales.getValueAt(fila, 0);
        Local local = lr.getById(id);
        FormEmpleados fe = new FormEmpleados(local);
        this.getParent().add(fe);
        fe.setVisible(true);
    }//GEN-LAST:event_btnListarEmpleadosActionPerformed

    private void cmbBarrioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbBarrioActionPerformed
        // Evento Buscar por barrio
        new Table<Local>().cargar(tblLocales, lr.getByBarrio(
                cmbBarrio.getItemAt(cmbBarrio.getSelectedIndex())));
    }//GEN-LAST:event_cmbBarrioActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // Evento eliminar
        if(tblLocales.getSelectedRow()==-1){ JOptionPane.showMessageDialog(this, 
                "Seleccione un local de la tabla.");
        } else {
        int fila=tblLocales.getSelectedRow();
        if(fila==-1) return;
        int id = (int) tblLocales.getValueAt(fila, 0);
        if(JOptionPane.showConfirmDialog(this, "¿Desea eliminar el local id:"+id+"?")!=0) return;
        Local local = lr.getById(id);
        if (er.getByLocal(local).size()!=0){
            JOptionPane.showMessageDialog(this, "El local no se puede "
                    + "eliminar porque tiene empleados.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        lr.remove(local);
        cargar();
        limpiar();
        lblConfirmacion.setText("El local fue removido de la base.");    
        }
    }//GEN-LAST:event_jButton1ActionPerformed

    public boolean validar(){
        if(!new Validator(txtDireccion).length(3, 35)) return false;
        return true;
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAgregarLocal;
    private javax.swing.JButton btnListarEmpleados;
    private javax.swing.JComboBox<Barrio> cmbBarrio;
    private javax.swing.JButton jButton1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lblBarrio;
    private javax.swing.JLabel lblConfirmacion;
    private javax.swing.JLabel lblDireccion;
    private javax.swing.JTable tblLocales;
    private javax.swing.JTextField txtDireccion;
    // End of variables declaration//GEN-END:variables

}
