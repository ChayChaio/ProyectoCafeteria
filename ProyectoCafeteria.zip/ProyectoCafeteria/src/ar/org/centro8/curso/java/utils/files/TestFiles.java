package ar.org.centro8.curso.java.utils.files;

import ar.org.centro8.curso.java.utils.files.FileText;
import ar.org.centro8.curso.java.utils.files.I_File;
import java.util.List;

public class TestFiles {

    public static void main(String[] args) {
        
        String file= "texto.txt";
        I_File fText= new FileText(file);
        fText.setText("Curso de java\n");
        fText.appendText("Hoy es lunes...");
        fText.addLine("Lunes");
        fText.addLine("Martes");
        fText.addLine("Miercoles");
        fText.addLine("Jueves");
        fText.addLine("Viernes");
        fText.addLines(List.of("Verano", "Invierno", "Otoño", "Primavera"));
        //System.out.println(fText.getText());
        fText.print();
        /*
        String text="";
        System.out.println(text+"\t"+text.hashCode());
        text+="h";
        System.out.println(text+"\t"+text.hashCode());
        text+="o";
        System.out.println(text+"\t"+text.hashCode());
        text+="l";
        System.out.println(text+"\t"+text.hashCode());
        text+="a";
        System.out.println(text+"\t"+text.hashCode());
        */
        
        fText.getAll().forEach(System.out::println);
        fText.getLikeFilter("v").forEach(System.out::println);
        fText.getLinkedHashSet().forEach(System.out::println);
        fText.getTreeSet().forEach(System.out::println);
        fText.remove("domingo");
        fText.getSortedLines().forEach(System.out::println);
        fText.getReversedSortedLines().forEach(System.out::println);
        
    }
    
}