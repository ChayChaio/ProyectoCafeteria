    package ar.org.centro8.curso.java.utils.files;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.TreeSet;
import java.util.stream.Collectors;

    public interface I_File {
        //Imprimo el texto
        default void print(){
            System.out.println(getText());
        }
        //Te devuelve el texto
        String getText();
        //Escribo el texto, eliminando si había antes algo
        void setText(String texto);
        //Agrego texto
        void appendText(String texto);
        //Limpiar el archivo
        default void clear(){
            setText("");
        }
        //Agrego una línea de texto
        default void addLine(String Line){
            appendText(Line+"\n");
        }
        //Agrego líneas
        default void addLines(List<String> lines){
            lines.forEach(this::addLine);
        }
        //Devuelve todo
        List<String> getAll();
        //Recorrer la lista buscando algo en el contenido
        default List<String> getLikeFilter(String filter){
            if (filter==null) return new ArrayList();
            return getAll()
                    .stream()
                    .filter(st->st.toLowerCase().contains(filter.toLowerCase()))
                    .collect(Collectors.toList());
        }
        //Pasar la lista de archivos a un LinkedHashSet(sin líneas duplicadas)
        default LinkedHashSet<String> getLinkedHashSet(){
            LinkedHashSet<String> set=new LinkedHashSet();
            set.addAll(getAll());
            return set;
        }
        //Para ordenarlos en un TreeSet
        default TreeSet<String> getTreeSet(){
            TreeSet<String> set=new TreeSet();
            set.addAll(getAll());
            return set;
        }
        //Otro orden natural por sorted()
        default List<String>getSortedLines(){
            return getAll()
                    .stream()
                    .sorted()
                    .collect(Collectors.toList());
        }
        //Orden invertido
        default List<String>getReversedSortedLines(){
            return getAll()
                    .stream()
                    .sorted(Comparator.reverseOrder())
                    .collect(Collectors.toList());
        }
        //remover linea
        default void remove(String line){
            List<String> list= getAll();
            list.remove(line);
            clear();
            addLines(list);
        }
        
        
    }
