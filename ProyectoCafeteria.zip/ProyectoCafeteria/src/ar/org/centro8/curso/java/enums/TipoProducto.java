package ar.org.centro8.curso.java.enums;
public enum TipoProducto {
    BEBIDA,
    COMIDA,
    GRANOS
}
