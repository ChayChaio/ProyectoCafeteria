package ar.org.centro8.curso.java.entities;

import ar.org.centro8.curso.java.enums.FormaDePago;
import ar.org.centro8.curso.java.enums.Tipo;

public class Factura {

    private int id;
    private Tipo tipo;
    private int numero;
    private int idLocal;
    private double monto;
    private double masIVA;
    private FormaDePago formaDePago;
    private String fecha;

    public Factura() {
    }

    public Factura(Tipo tipo, int numero, int idLocal, double monto, double masIVA, FormaDePago formaDePago, String fecha) {
        this.tipo = tipo;
        this.numero = numero;
        this.idLocal = idLocal;
        this.monto = monto;
        this.masIVA = masIVA;
        this.formaDePago = formaDePago;
        this.fecha = fecha;
    }

    public Factura(int id, Tipo tipo, int numero, int idLocal, double monto, double masIVA, FormaDePago formaDePago, String fecha) {
        this.id = id;
        this.tipo = tipo;
        this.numero = numero;
        this.idLocal = idLocal;
        this.monto = monto;
        this.masIVA = masIVA;
        this.formaDePago = formaDePago;
        this.fecha = fecha;
    }

    @Override
    public String toString() {
        return "Factura{" + "id=" + id + ", tipo=" + tipo + ", numero=" + numero 
                + ", idLocal=" + idLocal + ", monto=" + monto + ", masIVA=" + masIVA 
                + ", formaDePago=" + formaDePago + ", fecha=" + fecha + '}';
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Tipo getTipo() {
        return tipo;
    }

    public void setTipo(Tipo tipo) {
        this.tipo = tipo;
    }

    public int getNumero() {
        return numero;
    }

    public void setNumero(int numero) {
        this.numero = numero;
    }

    public int getIdLocal() {
        return idLocal;
    }

    public void setIdLocal(int idLocal) {
        this.idLocal = idLocal;
    }

    public double getMonto() {
        return monto;
    }

    public void setMonto(double monto) {
        this.monto = monto;
    }

    public double getMasIVA() {
        return masIVA;
    }

    public void setMasIVA(double masIVA) {
        this.masIVA = masIVA;
    }

    public FormaDePago getFormaDePago() {
        return formaDePago;
    }

    public void setFormaDePago(FormaDePago formaDePago) {
        this.formaDePago = formaDePago;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }
    
    
    
}