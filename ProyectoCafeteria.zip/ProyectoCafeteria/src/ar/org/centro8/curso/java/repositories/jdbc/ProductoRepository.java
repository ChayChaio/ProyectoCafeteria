package ar.org.centro8.curso.java.repositories.jdbc;

import ar.org.centro8.curso.java.entities.Producto;
import ar.org.centro8.curso.java.enums.TipoProducto;
import ar.org.centro8.curso.java.repositories.interfaces.I_ProductoRepository;
import java.util.List;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

public class ProductoRepository implements I_ProductoRepository{

    Connection conn;

    public ProductoRepository(Connection conn) {
        this.conn = conn;
    }
    
    @Override
    public void save(Producto producto) {
        if(producto==null) return;
        try (PreparedStatement ps=conn.prepareStatement("insert into productos "
                + "(nombre, descripcion, tipoProducto, precio) values (?, ?, ?, ?)",
                PreparedStatement.RETURN_GENERATED_KEYS)){
            ps.setString(1, producto.getNombre());
            ps.setString(2, producto.getDescripcion());
            ps.setString(3, producto.getTipoProducto()+"");
            ps.setDouble(4, producto.getPrecio());
            ps.execute();
            ResultSet rs=ps.getGeneratedKeys();
            if(rs.next()) producto.setId(rs.getInt(1));
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    @Override
    public void remove(Producto producto) {
        if(producto==null) return;
        try (PreparedStatement ps=conn.prepareStatement("delete from productos where id=?")){
            ps.setInt(1, producto.getId());
            ps.execute();
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    @Override
    public void update(Producto producto) {
        if(producto==null) return;
        try (PreparedStatement ps=conn.prepareStatement("update productos set "
                + "nombre=?, descripcion=?, tipoProducto=?, precio=? where id=?")){
            ps.setString(1, producto.getNombre());
            ps.setString(2, producto.getDescripcion());
            ps.setString(3, producto.getTipoProducto()+"");
            ps.setDouble(4, producto.getPrecio());
            ps.setInt(5, producto.getId());
            ps.execute();
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    @Override
    public List<Producto> getAll() {
        List<Producto> list = new ArrayList();
        try (ResultSet rs=conn.createStatement().executeQuery("select * from productos")){
            while(rs.next()) {
            list.add(new Producto(
                    rs.getInt("id"),
                    rs.getString("nombre"),
                    rs.getString("descripcion"),
                    TipoProducto.valueOf(rs.getString("tipoProducto")),
                    rs.getDouble("precio")
            ));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }

}