package ar.org.centro8.curso.java.repositories.jdbc;

import ar.org.centro8.curso.java.entities.Local;
import ar.org.centro8.curso.java.enums.Barrio;
import ar.org.centro8.curso.java.repositories.interfaces.I_LocalRepository;
import java.util.List;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

public class LocalRepository implements I_LocalRepository{

    Connection conn;

    public LocalRepository(Connection conn) {
        this.conn = conn;
    }
    
    @Override
    public void save(Local local) {
        if(local==null) return;
        try (PreparedStatement ps=conn.prepareStatement("insert into locales "
                + "(direccion, barrio, cantidadEmpleados) values (?, ?, ?)", 
                PreparedStatement.RETURN_GENERATED_KEYS)){
            ps.setString(1, local.getDireccion());
            ps.setString(2, local.getBarrio()+"");
            ps.setInt(3, local.getCantidadEmpleados());
            ps.execute();
            ResultSet rs=ps.getGeneratedKeys();
            if(rs.next()) local.setId(rs.getInt(1));
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    @Override
    public void remove(Local local) {
        if(local==null) return;
        try (PreparedStatement ps=conn.prepareStatement("delete from locales where id=?")){
            ps.setInt(1, local.getId());
            ps.execute();
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    @Override
    public void update(Local local) {
        if(local==null) return;
        try (PreparedStatement ps=conn.prepareStatement("update locales set "
                + "direccion=?, barrio=?, cantidadEmpleados=? where id=?")){
            ps.setString(1, local.getDireccion());
            ps.setString(2, local.getBarrio()+"");
            ps.setInt(3, local.getCantidadEmpleados());
            ps.setInt(4, local.getId());
            ps.execute();
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    @Override
    public List<Local> getAll() {
        List<Local> list = new ArrayList();
        try (ResultSet rs=conn.createStatement().executeQuery("select * from locales")){
            while(rs.next()){
                list.add(new Local(
                        rs.getInt("id"), 
                        rs.getString("direccion"), 
                        Barrio.valueOf(rs.getString("barrio")),
                        rs.getInt("cantidadEmpleados")
            ));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }

}