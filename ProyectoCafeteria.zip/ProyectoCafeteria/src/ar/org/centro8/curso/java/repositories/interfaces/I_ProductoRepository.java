package ar.org.centro8.curso.java.repositories.interfaces;

import java.util.List;
import ar.org.centro8.curso.java.entities.Producto;
import ar.org.centro8.curso.java.enums.TipoProducto;
import java.util.ArrayList;
import java.util.stream.Collectors;

public interface I_ProductoRepository {

    void save(Producto producto);        
    void remove(Producto producto);      
    void update(Producto producto);      
    List<Producto>getAll();            
    default Producto getById(int id){
        return getAll()
                .stream()
                .filter(p->p.getId()==id)
                .findAny()
                .orElse(new Producto());
    }
    
    default List<Producto> getByProducto(Producto producto){
        if(producto==null) return new ArrayList();
        return getAll()
                .stream()
                .filter(p->p.getId()==producto.getId())
                .collect(Collectors.toList());
    }
    
    default List<Producto> getLikeNombre(String nombre){
        if(nombre==null) return new ArrayList();
        return getAll()
                .stream()
                .filter(p->p.getNombre().toLowerCase().contains(nombre.toLowerCase()))
                .collect(Collectors.toList());
    }
    
    default List<Producto> getLikeDescripcion(String descripcion){
        if(descripcion==null) return new ArrayList();
        return getAll()
                .stream()
                .filter(p->p.getDescripcion().toLowerCase().contains(descripcion.toLowerCase()))
                .collect(Collectors.toList());
    }
    
    default List<Producto> getLikeNombreAndDescripcion(String nombre, String descripcion){
        if(nombre==null || descripcion==null) return new ArrayList();
        return getAll()
                .stream()
                .filter(p->p.getNombre().toLowerCase().contains(nombre.toLowerCase())
                && p.getDescripcion().toLowerCase().contains(descripcion.toLowerCase()))
                .collect(Collectors.toList());
    }
    
    default List<Producto> getByPrecio(double precio){
        return getAll()
                .stream()
                .filter(p->p.getPrecio()==precio)
                .collect(Collectors.toList());
    }
    
    default List<Producto> getByTipoProducto (TipoProducto tipoProducto){
        if(tipoProducto==null) return new ArrayList();
        return getAll()
                .stream()
                .filter(p->p.getTipoProducto()==tipoProducto)
                .collect(Collectors.toList());
    }
    
}
