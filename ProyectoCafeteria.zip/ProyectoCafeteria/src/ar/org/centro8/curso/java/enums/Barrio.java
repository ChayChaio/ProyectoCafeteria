package ar.org.centro8.curso.java.enums;
public enum Barrio {

    SAN_TELMO,
    CABALLITO,
    URQUIZA,
    NUÑEZ
    
}
