package ar.org.centro8.curso.java.enums;
public enum Barrio {
    SAN_TELMO,
    BALVANERA,
    ALMAGRO,
    CABALLITO,
    RECOLETA,
    BARRIO_NORTE,
    PALERMO,
    PALERMO_CHICO,
    PALERMO_VIEJO,
    PALERMO_SOHO,
    URQUIZA,
    BELGRANO,
    NUÑEZ
}
