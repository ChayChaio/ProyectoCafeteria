package ar.org.centro8.curso.java.entities;

public class Detalle {

    private int id;
    private int idFactura;
    private int idProducto;
    private double precio;

    public Detalle() {
    }

    public Detalle(int idFactura, int idProducto, double precio) {
        this.idFactura = idFactura;
        this.idProducto = idProducto;
        this.precio = precio;
    }

    public Detalle(int id, int idFactura, int idProducto, double precio) {
        this.id = id;
        this.idFactura = idFactura;
        this.idProducto = idProducto;
        this.precio = precio;
    }

    @Override
    public String toString() {
        return "Detalle{" + "id=" + id + ", idFactura=" + idFactura + 
                ", idProducto=" + idProducto + ", precio=" + precio + '}';
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getIdFactura() {
        return idFactura;
    }

    public void setIdFactura(int idFactura) {
        this.idFactura = idFactura;
    }

    public int getIdProducto() {
        return idProducto;
    }

    public void setIdProducto(int idProducto) {
        this.idProducto = idProducto;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }
    
    
    
}