insert into locales (idLocal, direccion, cantidadEmpleados) values
(1, 'SAN TELMO', 3),
(2, 'CABALLITO', 4),
(3, 'URQUIZA', 3),
(4, 'NUÑEZ', 5);

insert into productos (nombre, descripcion, precio) values
('Americano', 'Espresso en agua - 100ml', 120),
('Cafe doble', 'Espresso - 60ml', 130),
('Cortado', 'Espresso con leche cremada - 80ml', 125),
('Macchiato', 'Espresso con espuma - 80ml', 125),
('Lagrima', 'Leche cremada con un toque de café - 125ml', 135),
('Latte', 'Espresso, leche cremada y espuma - 190ml', 160),
('Cafe con leche', 'Espresso con leche cremada - 190ml', 150),
('Capuccino', 'Espresso, mitad leche cremada, mitad espuma - 190ml', 160),
('Cafe Vienes', 'En taza de vidrio: espresso(30ml), bocha de helado de crema 
                americana y crema batida.', 180),
('Affogato', 'En vaso de vidrio: dos espressos(60ml) y bocha de helado', 170),
('Chocolatada', 'Leche chocolatada cremada', 140),
('Mocha', 'Espresso con chocolate, leche cremada y espuma', 175),
('Brownie', 'Porcion de brownie solo - 100gr', 160),
('Brownie especial', 'Porcion de brownie con merengue italiano o dulce de leche', 200),
('Roll de canela', 'Pan dulce enrrollado con manteca y canela', 150),
('Cafe Excelso', 'Cafe Colombia en granos - 1kg', 1900),
('Cafe Santos Bourbon', 'Cafe Brasil en granos o molido - 1kg', 1500),
('Cafe Catuai', 'Cafe Brasil en granos - 250gr', 645),
('Cafe Guanes Genuino', 'Cafe Colombia en granos - 250gr', 930);

insert into empleados (idLocal, nombre, apellido, edad, posicion) values
(1, 'Jorge', 'Rodriguez', 21, 'EMPLEADO'),
(1, 'Mariana', 'Perez', 23, 'ENCARGADO'),
(1, 'Santiago', 'Dominguez', 25, 'EMPLEADO'),
(2, 'Ludmila', 'Ortiz', 22, 'DELIVERY'),
(2, 'Gisela', 'Gonzalez', 34, 'EMPLEADO'),
(2, 'Martin', 'Dominico', 29, 'ENCARGADO'),
(2, 'Juan', 'Boer', 20, 'EMPLEADO'),
(3, 'Esteban', 'Lento', 32, 'ENCARGADO'),
(3, 'Ana', 'Walker', 26, 'EMPLEADO'),
(3, 'Viviana', 'Agullo', 27, 'EMPLEADO'),
(4, 'Pedro', 'Marin', 31, 'EMPLEADO'),
(4, 'Ramiro', 'Martinez', 24, 'EMPLEADO'),
(4, 'Cristina', 'Ortega', 28, 'EMPLEADO'),
(4, 'Eugenia', 'Calvano', 30, 'ENCARGADO'),
(4, 'Lautaro', 'Neira', 19, 'DELIVERY');