insert into locales (id, direccion, barrio, cantidadEmpleados) values
(1,'Defensa 1045', 'SAN TELMO', 3),
(2, 'Caperucita 1139', 'CABALLITO', 4),
(3, 'Av Triunvirato 5470', 'URQUIZA', 3),
(4, 'Manzanaress 1653', 'NUÑEZ', 5);

insert into productos (nombre, descripcion, tipo, precio) values
('Americano', 'Espresso en agua - 100ml', 'BEBIDA', 120),
('Cafe doble', 'Espresso - 60ml', 'BEBIDA', 130),
('Cortado', 'Espresso con leche cremada - 80ml', 'BEBIDA', 125),
('Macchiato', 'Espresso con espuma - 80ml', 'BEBIDA', 125),
('Lagrima', 'Leche cremada con un toque de café - 125ml', 'BEBIDA', 135),
('Latte', 'Espresso, leche cremada y espuma - 190ml', 'BEBIDA', 160),
('Cafe con leche', 'Espresso con leche cremada - 190ml', 'BEBIDA', 150),
('Capuccino', 'Espresso, mitad leche cremada, mitad espuma - 190ml', 'BEBIDA', 160),
('Cafe Vienes', 'En taza de vidrio: espresso(30ml), bocha de helado de crema 
                americana y crema batida.', 'BEBIDA', 180),
('Affogato', 'En vaso de vidrio: dos espressos(60ml) y bocha de helado', 'BEBIDA', 170),
('Chocolatada', 'Leche chocolatada cremada', 'BEBIDA', 140),
('Mocha', 'Espresso con chocolate, leche cremada y espuma', 'BEBIDA', 175),
('Brownie', 'Porcion de brownie solo - 100gr', 'COMIDA', 160),
('Brownie especial', 'Porcion de brownie con merengue italiano o dulce de leche', 'COMIDA', 200),
('Roll de canela', 'Pan dulce enrrollado con manteca y canela', 'COMIDA', 150),
('Cafe Excelso', 'Cafe Colombia en granos - 1kg', 'GRANOS', 1900),
('Cafe Santos Bourbon', 'Cafe Brasil en granos o molido - 1kg', 'GRANOS', 1500),
('Cafe Catuai', 'Cafe Brasil en granos - 250gr', 'GRANOS', 645),
('Cafe Guanes Genuino', 'Cafe Colombia en granos - 250gr', 'GRANOS', 930);

insert into empleados (idLocal, nombre, apellido, edad, posicion) values
(1, 'Jorge', 'Rodriguez', 21, 'EMPLEADO'),
(1, 'Mariana', 'Perez', 23, 'ENCARGADO'),
(1, 'Santiago', 'Dominguez', 25, 'EMPLEADO'),
(2, 'Ludmila', 'Ortiz', 22, 'DELIVERY'),
(2, 'Gisela', 'Gonzalez', 34, 'EMPLEADO'),
(2, 'Martin', 'Dominico', 29, 'ENCARGADO'),
(2, 'Juan', 'Boer', 20, 'EMPLEADO'),
(3, 'Esteban', 'Lento', 32, 'ENCARGADO'),
(3, 'Ana', 'Walker', 26, 'EMPLEADO'),
(3, 'Viviana', 'Agullo', 27, 'EMPLEADO'),
(4, 'Pedro', 'Marin', 31, 'EMPLEADO'),
(4, 'Ramiro', 'Martinez', 24, 'EMPLEADO'),
(4, 'Cristina', 'Ortega', 28, 'EMPLEADO'),
(4, 'Eugenia', 'Calvano', 30, 'ENCARGADO'),
(4, 'Lautaro', 'Neira', 19, 'DELIVERY');

insert into facturas (tipo, numero, idLocal, monto, masIVA, formaDePago, fecha) values
('A', 0001, 1, 125, 151.25, 'MERCADOPAGO', '2021-05-17'),
('B', 0001, 1, 260, 314.60, 'DEBITO', '2021-05-17'),
('B', 0002, 2, 2210, 2674.10, 'CREDITO', '2021-05-17'),
('A', 0002, 4, 320, 387.20, 'EFECTIVO', '2021-05-17'),
('A', 0003, 2, 340, 411.40, 'DEBITO', '2021-05-17');

insert into detalles (idFactura, idProducto, precio) values
(1, 3, 125),
(2, 5, 135),
(2, 3, 125),
(3, 7, 150),
(3, 13, 160),
(3, 16, 1900),
(4, 6, 160),
(4, 6, 160),
(5, 8, 160),
(5, 9, 180);