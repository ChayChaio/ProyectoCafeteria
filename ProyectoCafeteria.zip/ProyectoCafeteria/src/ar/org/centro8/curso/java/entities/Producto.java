package ar.org.centro8.curso.java.entities;
import ar.org.centro8.curso.java.enums.TipoProducto;

public class Producto {

    private int id;
    private String nombre;
    private String descripcion;
    private TipoProducto producto;
    private double precio;

    public Producto() {
    }

    public Producto(String nombre, String descripcion, TipoProducto producto, double precio) {
        this.nombre = nombre;
        this.descripcion = descripcion;
        this.producto = producto;
        this.precio = precio;
    }

    public Producto(int id, String nombre, String descripcion, TipoProducto producto, double precio) {
        this.id = id;
        this.nombre = nombre;
        this.descripcion = descripcion;
        this.producto = producto;
        this.precio = precio;
    }

    @Override
    public String toString() {
        return "Producto{" + "id=" + id + ", nombre=" + nombre + ", descripcion=" 
                + descripcion + ", producto=" + producto + ", precio=" + precio + '}';
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public TipoProducto getProducto() {
        return producto;
    }

    public void setProducto(TipoProducto producto) {
        this.producto = producto;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }
    
    
    
}