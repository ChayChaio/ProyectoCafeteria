package ar.org.centro8.curso.java.repositories.interfaces;

import ar.org.centro8.curso.java.entities.Factura;
import ar.org.centro8.curso.java.entities.Local;
import ar.org.centro8.curso.java.enums.FormaDePago;
import ar.org.centro8.curso.java.enums.Tipo;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public interface I_FacturaRepository {

    void save(Factura factura);         
    void remove(Factura factura);       
    void update(Factura factura);       
    List<Factura>getAll();            
    default Factura getById(int id){
        return getAll()
                .stream()
                .filter(f->f.getId()==id)
                .findAny()
                .orElse(new Factura());
    }
    
    default List<Factura> getByFecha(String fecha){
        if (fecha==null) return new ArrayList();
        return getAll()
                .stream()
                .filter(f->f.getFecha().contains(fecha))
                .collect(Collectors.toList());
    }
    
    default List<Factura> getByFormaDePago (FormaDePago formaDePago){
        if (formaDePago==null) return new ArrayList();
        return getAll()
                .stream()
                .filter(f->f.getFormaDePago()==formaDePago)
                .collect(Collectors.toList());
    }
    
    default List<Factura> getByFormaDePagoAndLocal(FormaDePago formaDePago, Local local){
        if(formaDePago==null || local==null) return new ArrayList();
        return getAll()
                .stream()
                .filter(f->f.getFormaDePago()==formaDePago
                && f.getIdLocal()==local.getId())
                .collect(Collectors.toList());
    }
    
    default List<Factura> getByMontoMayorQue (double monto){
        return getAll()
                .stream()
                .filter(f->f.getMonto()>=monto)
                .collect(Collectors.toList());
    }
    
    default List<Factura> getByMontoMenorQue (double monto){
        return getAll()
                .stream()
                .filter(f->f.getMonto()<=monto)
                .collect(Collectors.toList());
    }
    
    default List<Factura> getByMasIVAMayorQue (double masIVA){
        return getAll()
                .stream()
                .filter(f->f.getMasIVA()>=masIVA)
                .collect(Collectors.toList());
    }
    
    default List<Factura> getByMasIVAMenorQue (double masIVA){
        return getAll()
                .stream()
                .filter(f->f.getMasIVA()<=masIVA)
                .collect(Collectors.toList());
    }
    
    default List<Factura> getByTipoAndNumero (Tipo tipo, int numero){
        if(tipo==null) return new ArrayList();
        return getAll()
                .stream()
                .filter(f->f.getTipo()==tipo && f.getNumero()==numero)
                .collect(Collectors.toList());
    }
    
    default List<Factura> getByFechaAndLocal(String fecha, Local local){
        if(fecha==null || local==null) return new ArrayList();
        return getAll()
                .stream()
                .filter(f->f.getFecha().contains(fecha)
                && f.getIdLocal()==local.getId())
                .collect(Collectors.toList());
    }
    
}
