drop table if exists locales;
drop table if exists productos;
drop table if exists empleados;
drop table if exists facturas;

create table locales(
    idLocal int primary key,
    direccion enum('SAN TELMO', 'CABALLITO', 'URQUIZA', 'NUÑEZ') not null,
    cantidadEmpleados int
);

create table productos(
    idProducto int auto_increment primary key,  --FK
    nombre varchar(25) not null,
    descripcion varchar(140),
    precio double not null
);

create table empleados(
    idEmpleado int auto_increment primary key,
    idLocal int,  --FK
    nombre varchar(25),
    apellido varchar(25) not null,
    edad int,
    posicion enum('EMPLEADO', 'ENCARGADO', 'DELIVERY')
);

create table facturas(
    tipo enum('A', 'B', 'C'),
    numero int,
    idLocal int,  --FK
    idProducto int,  --FK
    monto double,
    masIVA double,
    formaDePago enum ('EFECTIVO', 'DEBITO', 'CREDITO', 
                      'TRANSFERENCIA', 'MERCADOPAGO')
);

alter table empleados
    add constraint FK_Empleados_idLocal
    foreign key (idLocal)
    references locales(idLocal);

alter table facturas
    add constraint FK_Facturas_idLocal
    foreign key (idLocal)
    references locales(idLocal);

alter table facturas
    add constraint FK_Facturas_idProducto
    foreign key (idProducto)
    references productos(idProducto);