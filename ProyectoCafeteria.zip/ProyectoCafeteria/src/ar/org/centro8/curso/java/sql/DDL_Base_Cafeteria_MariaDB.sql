-- drop database if exists cafeteria;
-- create database cafeteria;
-- use cafeteria;
drop table if exists detalles;
drop table if exists facturas;
drop table if exists empleados;
drop table if exists locales;
drop table if exists productos;



create table locales(
    id int primary key,
    direccion varchar(50), 
    barrio enum('SAN TELMO', 'CABALLITO', 'URQUIZA', 'NUÑEZ') not null,
    cantidadEmpleados int
);

create table productos(
    id int auto_increment primary key,  -- FK
    nombre varchar(25) not null,
    descripcion varchar(140),
    tipo enum('BEBIDA', 'COMIDA', 'GRANOS'),
    precio double not null
);

create table empleados(
    id int auto_increment primary key,
    idLocal int,  -- FK
    nombre varchar(25),
    apellido varchar(25) not null,
    edad int,
    posicion enum('EMPLEADO', 'ENCARGADO', 'DELIVERY')
);

create table detalles(
    id int auto_increment primary key,
    idFactura int,  -- FK
    idProducto int,  -- FK
    precio double
);

create table facturas(
    id int auto_increment primary key,
    tipo enum('A', 'B', 'C'),
    numero int,
    idLocal int,  -- FK
    monto double,
    masIVA double,
    formaDePago enum ('EFECTIVO', 'DEBITO', 'CREDITO', 
                      'TRANSFERENCIA', 'MERCADOPAGO'),
    fecha date
);

alter table empleados
    add constraint FK_Empleados_idLocal
    foreign key (idLocal)
    references locales(id);

alter table facturas
    add constraint FK_Facturas_idLocal
    foreign key (idLocal)
    references locales(id);

alter table detalles
    add constraint FK_Detalles_idFactura
    foreign key (idFactura)
    references facturas(id);

alter table detalles
    add constraint FK_Detalles_idProducto
    foreign key (idProducto)
    references productos(id);